from secret import flag, gem, n


funny_list = [''] * n
a = None
b = 0

for i, j in enumerate(flag):
    funny_list[b] += j
    b += 1 if b == 0 or (b < n - 1 and (i // (n - 1)) % 2 == 0) else -1

fun = ' '.join(funny_list)

gem = gem.encode()
fun_bytes = fun.encode()

big_gem = (gem * (len(fun_bytes) // len(gem) + 1))[:len(fun_bytes)]

xored = bytes(a ^ b for a, b in zip(fun_bytes, big_gem))

with open('output.txt', 'w') as f:
    f.write(str(xored))
