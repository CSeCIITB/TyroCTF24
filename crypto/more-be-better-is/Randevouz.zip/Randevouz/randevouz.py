#!/usr/bin/python

import random
from Crypto.Cipher import DES as Magic
from Crypto.Util.Padding import pad, unpad

chars = 'abcedfghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890_@#$%^&*()!'

with open("flag.txt") as f:
    flag = f.read().strip()


k1 =  "SH"
k2 = "SH"
for i in range(3):
    k1 += random.choice(chars)
    k2 += random.choice(chars)

k1 += "SH!"
k2 += "SH!"


def Magic_Squared(plaintext, text_key, text_key2):
    key1 = text_key.encode()
    key2 = text_key2.encode()
    des1 = Magic.new(key1, Magic.MODE_ECB)
    des2 = Magic.new(key2, Magic.MODE_ECB)
    padded_text = pad(plaintext.encode(), Magic.block_size)
    intermediate = des1.encrypt(padded_text)
    ciphertext = des2.encrypt(intermediate)
    return ciphertext


ct = Magic_Squared(flag, k1, k2)


print("ct: ", ct)
