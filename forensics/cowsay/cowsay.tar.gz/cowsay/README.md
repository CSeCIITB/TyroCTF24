# Cowsay

My custom `cowsay` script written in `python`!!

```plaintext
Usage: python3 cowsay.py <your text here>
```

